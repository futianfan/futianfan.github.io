STRML.net
=========

[View Site](http://strml.net)

Building
--------

```bash
git clone git@github.com:STRML/strml.net.git
cd strml.net
npm install
npm run dev
# Open localhost:4003/index-dev.html in your browser
```

Building for Production
--------

```bash
npm run build
```
